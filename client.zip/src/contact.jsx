import React from 'react'
import './contact.css'

function Contact() {
  return (

    <>
    
    
    <form>



        
    </form>
    
    
    </>

  )
}

export default Contact