// const host = "http://localhost:3003";
const host ="https://beetreeapi.onrender.com"
const loginRoute = `${host}/api/auth/login`;
const registerRoute = `${host}/api/auth/register`;
const BeehiveRoute = `${host}/api/hives`;


export { host, BeehiveRoute,loginRoute, registerRoute };
