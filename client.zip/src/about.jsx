import React from 'react'
import './about.css'


function About() {


  return (


    <>

        <section className="main" id = "about">

            <div className="title">

                <p>Hello, <span>&#128075;</span> I am <span id ='name'>Philip Waruinge </span> and I sell <span id = 'name'><i> Quality</i> </span> Bee Hives.<br></br>Welcome to HoneyPot.</p>


                {/* <div class="typewriter">
                  <span class="text-1">First Text</span>
                  <span class="text-2">Second Text</span>
                </div> */}

            </div>















        </section>
    


    
    
    
    
    
    </>


  )
}

export default About